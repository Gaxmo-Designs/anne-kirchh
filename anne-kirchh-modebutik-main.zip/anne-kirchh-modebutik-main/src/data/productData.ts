
import { Product } from "@/types/product";

export const getProducts = (): Promise<Product[]> => {
  return new Promise((resolve) => {
    // Simulate network delay
    setTimeout(() => {
      const products: Product[] = [
        {
          id: 1,
          name: "Farverigt tørklæde - Blå/orange",
          price: "299,95 kr.",
          category: "scarves",
          primaryImage: "/lovable-uploads/b415f3cf-5371-4746-93ec-7ac95bb8ba6b.png",
          description: "Lækkert tørklæde i flotte farver. Perfekt til at give dit outfit et farverigt touch."
        },
        {
          id: 2,
          name: "Farverigt tørklæde - Pink/lilla",
          price: "299,95 kr.",
          category: "scarves",
          primaryImage: "/lovable-uploads/dea643ea-bf06-4956-a88c-8cb22fe0eae1.png",
          description: "Lækkert tørklæde i varme farver. Perfekt til at give dit outfit et farverigt touch."
        },
        {
          id: 3,
          name: "Denim jakke",
          price: "599,95 kr.",
          category: "jackets",
          primaryImage: "/lovable-uploads/7-6.png",
          secondaryImage: "/lovable-uploads/7-7.png",
          description: "Klassisk denim jakke i høj kvalitet. Et must-have i enhver garderobe."
        },
        {
          id: 4,
          name: "Ballon nederdel - Beige",
          price: "399,95 kr.",
          category: "skirts",
          primaryImage: "/lovable-uploads/10-9.png",
          secondaryImage: "/lovable-uploads/10-10.png",
          description: "Elegant ballon nederdel i beige. Perfekt til både hverdag og fest.",
          size: "S, M, L"
        },
        {
          id: 5,
          name: "Mesh ballerina sko med similisten",
          price: "349,95 kr.",
          category: "shoes",
          primaryImage: "/lovable-uploads/11-11.png",
          secondaryImage: "/lovable-uploads/12-12.png",
          description: "Elegante mesh ballerina sko med similisten. Komfortable og stilfulde."
        },
        {
          id: 6,
          name: "Blazer - Rosa",
          price: "699,95 kr.",
          category: "blazers",
          primaryImage: "/lovable-uploads/15-15.png",
          secondaryImage: "/lovable-uploads/16-16.png",
          description: "Stilfuld blazer i rosa. Perfekt til at opgradere dit outfit.",
          size: "36-44"
        },
        {
          id: 7,
          name: "T-shirt med blomster print",
          price: "199,95 kr.",
          category: "shirts",
          primaryImage: "/lovable-uploads/20-20.png",
          description: "Fin t-shirt med sødt blomsterprint. Blød og behagelig kvalitet.",
          size: "S, M, L, XL"
        },
        {
          id: 8,
          name: "T-shirt med Rock print",
          price: "199,95 kr.",
          category: "shirts",
          primaryImage: "/lovable-uploads/19-19.png",
          description: "Cool t-shirt med rock print. Perfekt til en afslappet stil.",
          size: "S, M, L, XL"
        },
        {
          id: 9,
          name: "T-shirt med libelle print",
          price: "199,95 kr.",
          category: "shirts",
          primaryImage: "/lovable-uploads/18-18.png",
          description: "Elegant t-shirt med libelle print. Høj kvalitet og god pasform.",
          size: "S, M, L, XL"
        },
        {
          id: 10,
          name: "Jeans - Lyseblå",
          price: "699,95 kr.",
          category: "jeans",
          primaryImage: "/lovable-uploads/23-23.png",
          description: "Komfortable jeans i lyseblå. Perfekt pasform og høj kvalitet.",
          size: "36-46"
        },
        {
          id: 11,
          name: "Offwhite kjole med smock fra Cream",
          price: "599,95 kr.",
          category: "dresses",
          primaryImage: "/lovable-uploads/24-24.png",
          secondaryImage: "/lovable-uploads/25-25.png",
          description: "Elegant offwhite kjole med smock fra Cream. 100% viskose.",
          size: "36-44"
        },
        {
          id: 12,
          name: "Blå kjole med smock fra Cream",
          price: "599,95 kr.",
          category: "dresses",
          primaryImage: "/lovable-uploads/26-26.png",
          description: "Smuk blå kjole med smock fra Cream. 100% viskose.",
          size: "36-44"
        },
        {
          id: 13,
          name: "Blazer jakke - Beige",
          price: "499,95 kr.",
          category: "blazers",
          primaryImage: "/lovable-uploads/28-28.png",
          description: "Elegant beige blazer i tidløst design. Perfekt til både kontoret og festlige lejligheder.",
          size: "36-44"
        },
        {
          id: 14,
          name: "Vest - Beige",
          price: "499,95 kr.",
          category: "accessories",
          primaryImage: "/lovable-uploads/29-29.png",
          description: "Stilfuld beige vest som komplimenterer vores blazer jakke perfekt.",
          size: "36-44"
        },
        {
          id: 15,
          name: "Bukser - Beige",
          price: "499,95 kr.",
          category: "jeans",
          primaryImage: "/lovable-uploads/30-30.png",
          description: "Elegante beige bukser i høj kvalitet. Matcher perfekt til vores blazer og vest.",
          size: "36-44"
        },
        {
          id: 16,
          name: "Solbriller - Brun",
          price: "399,95 kr.",
          category: "accessories",
          primaryImage: "/lovable-uploads/31-31.png",
          description: "Stilfulde solbriller i brun. UV-beskyttende og i moderne design."
        },
        {
          id: 17,
          name: "Strikbluse - Blå",
          price: "299,95 kr.",
          category: "sweaters",
          primaryImage: "/lovable-uploads/32-32.png",
          description: "Blød strikbluse i smuk blå farve. Perfekt til kølige dage.",
          size: "S, M, L, XL"
        },
        {
          id: 18,
          name: "Strikbluse - Grøn",
          price: "299,95 kr.",
          category: "sweaters",
          primaryImage: "/lovable-uploads/33-33.png",
          description: "Blød strikbluse i flot grøn farve. Komfortabel og stilfuld.",
          size: "S, M, L, XL"
        },
        {
          id: 19,
          name: "Skjorte - Blå/rosa strib",
          price: "499,95 kr.",
          category: "shirts",
          primaryImage: "/lovable-uploads/36-36.png",
          description: "Elegant skjorte i blå med rosa broderi. Perfekt til både hverdag og fest.",
          size: "S, M, L"
        },
        {
          id: 20,
          name: "Taske fra Redesigned",
          price: "800,00 kr.",
          category: "bags",
          primaryImage: "/lovable-uploads/37-37.png",
          secondaryImage: "/lovable-uploads/39-39.png",
          description: "Håndlavet lædertaske fra Redesigned. Rummelig og i tidløst design."
        },
        {
          id: 21,
          name: "Jakke fra Sorbet",
          price: "499,95 kr.",
          category: "jackets",
          primaryImage: "/lovable-uploads/41-41.png",
          description: "Stilfuld jakke fra Sorbet. Perfekt til at fuldende dit outfit."
        },
        {
          id: 22,
          name: "Top fra Cream",
          price: "299,95 kr.",
          category: "shirts",
          primaryImage: "/lovable-uploads/42-42.png",
          description: "Elegant top fra Cream. Let og luftig kvalitet."
        }
      ];
      resolve(products);
    }, 500);
  });
};
