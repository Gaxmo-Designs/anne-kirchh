
import React from "react";
import ImageWithPreload from "./ui/ImageWithPreload";

interface MarqueeSliderProps {
  images: { src: string; alt: string }[];
}

const MarqueeSlider: React.FC<MarqueeSliderProps> = ({ images }) => {
  return (
    <div className="overflow-hidden w-full py-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {images.map((image, index) => (
          <div 
            key={`image-${index}`}
            className="w-full aspect-[5/7] flex-shrink-0 bg-white/50 rounded-lg shadow-md overflow-hidden border border-white/20 transition-transform duration-300 hover:shadow-lg hover:scale-[1.02]"
          >
            <ImageWithPreload
              src={image.src}
              alt={image.alt}
              className="h-full w-full object-cover"
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default MarqueeSlider;
