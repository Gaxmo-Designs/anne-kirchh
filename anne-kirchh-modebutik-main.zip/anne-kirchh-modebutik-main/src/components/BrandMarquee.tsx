
import React from "react";
import { Heart } from "lucide-react";

interface BrandMarqueeProps {
  brands: string[];
}

const BrandMarquee: React.FC<BrandMarqueeProps> = ({ brands }) => {
  // Duplicate brands for continuous scrolling effect
  const duplicatedBrands = [...brands, ...brands, ...brands];
  
  return (
    <div className="py-8 bg-gradient-to-r from-purple-50 to-pink-50 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-10 w-16 h-16 rounded-full bg-pink-200 opacity-20"></div>
      <div className="absolute bottom-0 left-1/4 w-12 h-12 rounded-full bg-green-200 opacity-20"></div>
      <div className="absolute top-1/2 right-1/3 w-8 h-8 rounded-full bg-purple-200 opacity-20"></div>
      
      <div className="container mx-auto px-4 mb-6">
        <div className="text-center mb-6">
          <h2 className="text-3xl md:text-4xl font-display mb-4 bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-purple-500">
            Vores eksklusive mærker
          </h2>
          <p className="text-base text-muted-foreground max-w-xl mx-auto font-serif">
            Vi samarbejder med nogle af de bedste brands for at give dig den bedste kvalitet og stil
          </p>
        </div>
      </div>
      
      <div className="relative overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap space-x-8 py-4 px-4">
          {duplicatedBrands.map((brand, index) => (
            <div 
              key={index} 
              className="flex flex-col items-center justify-center min-w-[180px] px-6 py-4 bg-white/80 backdrop-blur-sm rounded-lg shadow-sm border border-white/20"
            >
              <h3 className="text-xl font-display text-gray-800">{brand}</h3>
              <div className="mt-2 flex items-center">
                <Heart className="h-3 w-3 text-pink-400 mr-1" />
                <Heart className="h-4 w-4 text-pink-400 mr-1" />
                <Heart className="h-3 w-3 text-pink-400" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BrandMarquee;
