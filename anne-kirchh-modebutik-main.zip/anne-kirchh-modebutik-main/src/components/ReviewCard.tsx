
import React from "react";
import { Star, StarHalf } from "lucide-react";

interface ReviewCardProps {
  name: string;
  rating: number;
  comment: string;
}

const ReviewCard: React.FC<ReviewCardProps> = ({ name, rating, comment }) => {
  // Generate stars based on rating
  const renderStars = () => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-primary text-primary w-4 h-4" />);
    }
    
    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-primary text-primary w-4 h-4" />);
    }
    
    // Add empty stars to make a total of 5
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-gray-300 w-4 h-4" />);
    }
    
    return stars;
  };
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-beige">
      <div className="flex items-center mb-4">
        {renderStars()}
      </div>
      <p className="mb-4 italic text-muted-foreground">"{comment}"</p>
      <p className="font-medium">{name}</p>
    </div>
  );
};

export default ReviewCard;
