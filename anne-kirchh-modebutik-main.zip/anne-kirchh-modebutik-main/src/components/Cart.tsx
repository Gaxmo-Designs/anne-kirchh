
import React from "react";
import { useCart, CartItem } from "@/context/CartContext";
import { X, Plus, Minus, ShoppingBag, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import ImageWithPreload from "./ui/ImageWithPreload";

const Cart: React.FC = () => {
  const { cartItems, removeFromCart, updateQuantity, cartTotal, isCartOpen, setIsCartOpen, cartCount } = useCart();

  return (
    <>
      {/* Cart Button */}
      <button 
        className="relative p-2 text-purple-800 transition-colors hover:text-pink-500"
        onClick={() => setIsCartOpen(true)}
      >
        <ShoppingBag size={24} />
        {cartCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-gradient-to-r from-pink-500 to-purple-500 text-white w-5 h-5 flex items-center justify-center rounded-full text-xs">
            {cartCount}
          </span>
        )}
      </button>
      
      {/* Cart Sidebar */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm transition-opacity">
          <div 
            className="absolute h-full w-full" 
            onClick={() => setIsCartOpen(false)}
          />
          
          <div className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-xl animate-slide-in-right">
            <div className="flex h-full flex-col">
              {/* Header */}
              <div className="border-b px-6 py-4 flex items-center justify-between">
                <h2 className="text-xl font-display">Din indkøbskurv</h2>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="rounded-full p-1.5 text-gray-500 hover:bg-gray-100"
                >
                  <X size={18} />
                </button>
              </div>
              
              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto p-6">
                {cartItems.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full">
                    <ShoppingBag size={48} className="text-gray-300 mb-4" />
                    <p className="text-gray-500 mb-6">Din kurv er tom</p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="px-6 py-2 bg-gradient-to-r from-pink-400 to-purple-400 text-white rounded-md"
                    >
                      Fortsæt shopping
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {cartItems.map((item, index) => (
                      <CartItemCard 
                        key={`${item.id}-${item.size}-${index}`} 
                        item={item} 
                        removeFromCart={removeFromCart}
                        updateQuantity={updateQuantity}
                      />
                    ))}
                  </div>
                )}
              </div>
              
              {/* Footer */}
              {cartItems.length > 0 && (
                <div className="border-t p-6 space-y-4">
                  <div className="flex justify-between text-lg font-medium">
                    <span>Total:</span>
                    <span>{cartTotal}</span>
                  </div>
                  
                  <Link 
                    to="/checkout" 
                    className="block w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white py-3 rounded-md text-center font-medium hover:from-pink-600 hover:to-purple-600 transition-colors"
                    onClick={() => setIsCartOpen(false)}
                  >
                    Gå til betaling
                  </Link>
                  
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="block w-full border border-gray-200 py-2 rounded-md text-center text-sm hover:bg-gray-50 transition-colors"
                  >
                    Fortsæt shopping
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

const CartItemCard: React.FC<{
  item: CartItem;
  removeFromCart: (id: number, size: string) => void;
  updateQuantity: (id: number, size: string, quantity: number) => void;
}> = ({ item, removeFromCart, updateQuantity }) => {
  return (
    <div className="flex items-start gap-4 py-3 border-b border-gray-100">
      <div className="h-20 w-16 flex-shrink-0 bg-purple-50 rounded overflow-hidden">
        <ImageWithPreload
          src={item.image}
          alt={item.name}
          className="h-full w-full object-cover"
        />
      </div>
      
      <div className="flex-1 min-w-0">
        <h3 className="text-sm font-medium line-clamp-2">{item.name}</h3>
        <p className="text-xs text-gray-500 mt-1">Størrelse: {item.size}</p>
        <p className="text-sm font-medium mt-1">{item.price}</p>
        
        <div className="flex items-center mt-2">
          <button 
            onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)}
            className="p-1 rounded-full text-gray-500 hover:bg-gray-100"
          >
            <Minus size={14} />
          </button>
          
          <span className="w-8 text-center text-sm">{item.quantity}</span>
          
          <button 
            onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)}
            className="p-1 rounded-full text-gray-500 hover:bg-gray-100"
          >
            <Plus size={14} />
          </button>
        </div>
      </div>
      
      <button 
        onClick={() => removeFromCart(item.id, item.size)}
        className="p-1.5 text-gray-400 hover:text-red-500"
      >
        <Trash2 size={16} />
      </button>
    </div>
  );
};

export default Cart;
