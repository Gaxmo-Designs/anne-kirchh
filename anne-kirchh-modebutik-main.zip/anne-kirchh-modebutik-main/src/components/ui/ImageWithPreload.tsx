
import React, { useState, useEffect } from "react";

interface ImageWithPreloadProps {
  src: string;
  alt: string;
  className?: string;
  width?: string | number;
  height?: string | number;
}

const ImageWithPreload: React.FC<ImageWithPreloadProps> = ({
  src,
  alt,
  className = "",
  width,
  height
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  const [error, setError] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.src = src;
    img.onload = () => {
      setIsLoaded(true);
      setImageUrl(src);
      setError(false);
    };
    img.onerror = () => {
      console.error(`Failed to load image: ${src}`);
      setError(true);
      setIsLoaded(true); // Still mark as loaded to remove loading state
    };

    // Set a timeout in case the image takes too long to load
    const timeoutId = setTimeout(() => {
      if (!isLoaded) {
        console.warn(`Image load timeout: ${src}`);
        setIsLoaded(true);
        setImageUrl(src); // Try to show the image anyway
      }
    }, 5000);

    return () => clearTimeout(timeoutId);
  }, [src, isLoaded]);

  return (
    <div 
      className={`relative overflow-hidden ${className} ${isLoaded ? "lazy-image loaded" : "lazy-image loading"}`}
      style={{ width, height }}
    >
      {error ? (
        <div className="w-full h-full flex items-center justify-center bg-pink-50 text-pink-500">
          <p className="text-sm">Billede kunne ikke indlæses</p>
        </div>
      ) : !isLoaded ? (
        <div className="w-full h-full bg-gradient-to-r from-pink-50 to-purple-50 animate-pulse"></div>
      ) : (
        <img
          src={imageUrl}
          alt={alt}
          className={`w-full h-full object-cover transition-opacity duration-500 ${isLoaded ? "opacity-100" : "opacity-0"}`}
          loading="eager"
        />
      )}
    </div>
  );
};

export default ImageWithPreload;
