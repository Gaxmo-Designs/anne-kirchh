
import { Link } from "react-router-dom";
import { Facebook, Instagram, MapPin, Phone, Mail, Clock } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-beige/30 pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-16">
          <div className="space-y-4">
            <h4 className="text-lg font-medium uppercase tracking-wider mb-6 text-primary">Om Anne Kirchh</h4>
            <p className="text-muted-foreground">
              Anne Kirchh er din eksklusive modebutik i Værløse. Vi klæder både unge piger og modne kvinder på til enhver lejlighed med nøje udvalgte kollektioner af tøj, smykker og accessories.
            </p>
            <div className="flex space-x-4 pt-4">
              <a 
                href="https://www.facebook.com/butikannekirchh" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a 
                href="https://www.instagram.com/annekirchh/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4 className="text-lg font-medium uppercase tracking-wider mb-6 text-primary">Links</h4>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="hover:text-primary transition-colors">Hjem</Link>
              </li>
              <li>
                <Link to="/collection" className="hover:text-primary transition-colors">Kollektion</Link>
              </li>
              <li>
                <Link to="/products" className="hover:text-primary transition-colors">Produkter</Link>
              </li>
              <li>
                <Link to="/reviews" className="hover:text-primary transition-colors">Anmeldelser</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-primary transition-colors">Kontakt</Link>
              </li>
            </ul>
          </div>
          
          <div className="space-y-4">
            <h4 className="text-lg font-medium uppercase tracking-wider mb-6 text-primary">Kontakt</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 mr-3 mt-0.5 text-primary" />
                <span>Anne Kirchh<br />Bymidten 43<br />3500 Værløse</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-5 h-5 mr-3 text-primary" />
                <a href="tel:+4544473711" className="hover:text-primary transition-colors">44 47 37 11</a>
              </li>
              <li className="flex items-center">
                <Mail className="w-5 h-5 mr-3 text-primary" />
                <a href="mailto:butikkenak@gmail.com" className="hover:text-primary transition-colors">butikkenak@gmail.com</a>
              </li>
              <li className="flex items-start">
                <Clock className="w-5 h-5 mr-3 mt-0.5 text-primary" />
                <div>
                  <p>Mandag-fredag: 9.30-18.00</p>
                  <p>Lørdag: 9.30-15.00</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-muted pt-8 mt-8 text-center text-sm text-muted-foreground">
          <p>© {currentYear} Anne Kirchh. Alle rettigheder forbeholdes.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
