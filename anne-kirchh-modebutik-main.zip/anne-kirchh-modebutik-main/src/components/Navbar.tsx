
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, ChevronDown } from "lucide-react";
import Cart from "./Cart";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const location = useLocation();
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  
  useEffect(() => {
    // Close mobile menu when route changes
    setIsMenuOpen(false);
  }, [location]);
  
  return (
    <header 
      className={`fixed w-full z-40 transition-all duration-300 ${
        isScrolled 
          ? "bg-white shadow-md py-2" 
          : "bg-transparent py-4"
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="font-display text-2xl font-bold">
            <span className={`${isScrolled ? "text-primary" : "text-white"}`}>
              ANNE KIRCHH
            </span>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            <Link 
              to="/" 
              className={`px-3 py-2 rounded-md font-medium ${
                location.pathname === "/" 
                  ? "text-pink-500"
                  : isScrolled ? "text-primary hover:text-pink-500" : "text-white hover:text-pink-200"
              } transition-colors`}
            >
              Forside
            </Link>
            
            {/* Collection dropdown */}
            <div className="relative group">
              <button 
                className={`flex items-center px-3 py-2 rounded-md font-medium ${
                  location.pathname.includes("/collection") || location.pathname.includes("/products") || location.pathname.includes("/spring-collection")
                    ? "text-pink-500"
                    : isScrolled ? "text-primary hover:text-pink-500" : "text-white hover:text-pink-200"
                } transition-colors`}
                onClick={toggleDropdown}
              >
                Kollektioner
                <ChevronDown size={16} className="ml-1" />
              </button>
              
              <div className={`absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg overflow-hidden transition-all duration-200 ${dropdownOpen ? 'block' : 'hidden'} group-hover:block z-10`}>
                <Link 
                  to="/collection" 
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600"
                >
                  Alle Kollektioner
                </Link>
                <Link 
                  to="/products" 
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600"
                >
                  Alle Produkter
                </Link>
                <Link 
                  to="/spring-collection" 
                  className="block px-4 py-2 text-sm text-gray-700 hover:bg-pink-50 hover:text-pink-600"
                >
                  Forårskollektion 2024
                </Link>
              </div>
            </div>
            
            <Link 
              to="/reviews" 
              className={`px-3 py-2 rounded-md font-medium ${
                location.pathname === "/reviews" 
                  ? "text-pink-500"
                  : isScrolled ? "text-primary hover:text-pink-500" : "text-white hover:text-pink-200"
              } transition-colors`}
            >
              Anmeldelser
            </Link>
            
            <Link 
              to="/contact" 
              className={`px-3 py-2 rounded-md font-medium ${
                location.pathname === "/contact" 
                  ? "text-pink-500"
                  : isScrolled ? "text-primary hover:text-pink-500" : "text-white hover:text-pink-200"
              } transition-colors`}
            >
              Kontakt
            </Link>
          </nav>
          
          {/* Cart and Mobile Menu Button */}
          <div className="flex items-center">
            {/* Shopping Cart */}
            <div className={isScrolled ? "text-primary" : "text-white"}>
              <Cart />
            </div>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden ml-4" 
              onClick={toggleMenu}
            >
              {isMenuOpen ? (
                <X size={24} className={isScrolled ? "text-primary" : "text-white"} />
              ) : (
                <Menu size={24} className={isScrolled ? "text-primary" : "text-white"} />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div 
        className={`md:hidden absolute top-full left-0 right-0 bg-white shadow-lg transition-transform duration-300 ease-in-out ${
          isMenuOpen ? "translate-y-0" : "-translate-y-full"
        }`}
      >
        <div className="container mx-auto px-4 py-4">
          <nav className="flex flex-col space-y-2">
            <Link 
              to="/" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === "/" ? "bg-pink-50 text-pink-500" : ""
              }`}
            >
              Forside
            </Link>
            
            <Link 
              to="/collection" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === "/collection" ? "bg-pink-50 text-pink-500" : ""
              }`}
            >
              Kollektioner
            </Link>

            <Link 
              to="/spring-collection" 
              className={`px-3 py-2 rounded-md pl-6 text-sm ${
                location.pathname === "/spring-collection" ? "bg-pink-50 text-pink-500" : "text-gray-600"
              }`}
            >
              Forårskollektion 2024
            </Link>
            
            <Link 
              to="/products" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === "/products" ? "bg-pink-50 text-pink-500" : ""
              }`}
            >
              Produkter
            </Link>
            
            <Link 
              to="/reviews" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === "/reviews" ? "bg-pink-50 text-pink-500" : ""
              }`}
            >
              Anmeldelser
            </Link>
            
            <Link 
              to="/contact" 
              className={`px-3 py-2 rounded-md ${
                location.pathname === "/contact" ? "bg-pink-50 text-pink-500" : ""
              }`}
            >
              Kontakt
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
