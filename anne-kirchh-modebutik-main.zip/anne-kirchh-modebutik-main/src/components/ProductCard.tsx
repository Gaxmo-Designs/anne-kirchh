
import React, { useState } from "react";
import ImageWithPreload from "./ui/ImageWithPreload";
import { Heart, ShoppingBag, X } from "lucide-react";
import { useCart } from "@/context/CartContext";

interface ProductCardProps {
  id: number;
  name: string;
  price: string;
  primaryImage: string;
  secondaryImage?: string;
  description?: string;
  size?: string;
}

const ProductCard: React.FC<ProductCardProps> = ({
  id,
  name,
  price,
  primaryImage,
  secondaryImage,
  description,
  size,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [selectedSize, setSelectedSize] = useState("");
  const { addToCart } = useCart();
  
  const handleQuickView = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsOpen(true);
  };
  
  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  const handleAddToCart = () => {
    // For products without size options, allow direct add
    if (!size || selectedSize) {
      addToCart({
        id,
        name,
        price,
        image: primaryImage,
        size: selectedSize || "One Size",
        quantity: 1
      });
      
      // Show confirmation message or toast here
      setIsOpen(false);
    }
  };
  
  return (
    <>
      <div 
        className="relative overflow-hidden transition-all duration-300 ease-in-out group"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="product-card mb-4 bg-white">
          <div className="relative aspect-[2/3] overflow-hidden">
            <ImageWithPreload
              src={isHovered && secondaryImage ? secondaryImage : primaryImage}
              alt={name}
              className="w-full h-full object-cover transition-transform duration-700"
            />
            
            {/* Favorite button */}
            <button 
              onClick={toggleFavorite}
              className="absolute top-2 right-2 bg-white/80 p-2 rounded-full z-10 transition-transform duration-300 hover:scale-110"
            >
              <Heart 
                size={18} 
                className={isFavorite ? "fill-pink-500 text-pink-500" : "text-gray-500"} 
              />
            </button>
            
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300"></div>
            <div className="absolute bottom-0 left-0 right-0 p-4 opacity-0 transform translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
              <button 
                onClick={handleQuickView}
                className="w-full bg-white/90 backdrop-blur-sm text-primary py-2 rounded-md text-sm uppercase tracking-wider hover:bg-white transition-colors flex items-center justify-center space-x-2"
              >
                <ShoppingBag size={16} />
                <span>Hurtig visning</span>
              </button>
            </div>
          </div>
        </div>
        <h3 className="font-serif text-base">{name}</h3>
        <p className="text-primary font-medium mt-1">{price}</p>
        {size && <p className="text-sm text-muted-foreground mt-1 font-sans">{size}</p>}
      </div>
      
      {/* Quick View Modal */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setIsOpen(false)}
        >
          <div 
            className="bg-white max-w-4xl w-full rounded-xl overflow-hidden opacity-0 scale-95 animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <button 
                onClick={() => setIsOpen(false)}
                className="absolute top-4 right-4 bg-white/80 p-2 rounded-full z-10 transition-transform duration-300 hover:scale-110"
              >
                <X size={20} className="text-gray-500" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-6 flex items-center justify-center bg-gradient-to-br from-purple-50 to-pink-50">
                <ImageWithPreload
                  src={primaryImage}
                  alt={name}
                  className="max-h-[500px] object-contain"
                />
              </div>
              <div className="p-8 flex flex-col relative">
                {/* Decorative elements */}
                <div className="absolute top-8 right-8 w-20 h-20 rounded-full bg-pink-100 opacity-20 -z-10"></div>
                <div className="absolute bottom-8 left-12 w-16 h-16 rounded-full bg-purple-100 opacity-20 -z-10"></div>
                
                <h2 className="text-2xl font-display mb-2">{name}</h2>
                <p className="text-xl text-primary font-medium mb-4">{price}</p>
                {size && (
                  <div className="mb-4">
                    <h3 className="text-sm uppercase tracking-wider font-medium mb-2">Størrelse</h3>
                    <div className="flex flex-wrap gap-2">
                      {size.split(', ').map((sizeOption, index) => (
                        <div 
                          key={index} 
                          className={`px-3 py-1 border rounded-md text-sm cursor-pointer transition-colors ${
                            selectedSize === sizeOption 
                              ? "border-pink-500 bg-pink-50 text-pink-700" 
                              : "border-gray-200 hover:border-pink-300"
                          }`}
                          onClick={() => setSelectedSize(sizeOption)}
                        >
                          {sizeOption}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {description && (
                  <div className="mb-6">
                    <h3 className="text-sm uppercase tracking-wider font-medium mb-2">Beskrivelse</h3>
                    <p className="text-muted-foreground font-serif">{description}</p>
                  </div>
                )}
                <div className="mt-auto space-y-3">
                  <button 
                    className={`w-full bg-gradient-to-r from-pink-400 to-purple-400 text-white py-3 rounded-md uppercase tracking-wider flex items-center justify-center ${
                      size && !selectedSize 
                        ? "opacity-70 cursor-not-allowed" 
                        : "hover:from-pink-500 hover:to-purple-500"
                    } transition-colors`}
                    onClick={handleAddToCart}
                    disabled={size && !selectedSize}
                  >
                    <ShoppingBag className="mr-2" size={18} />
                    Læg i kurv
                  </button>
                  
                  <button 
                    className="w-full border border-gray-200 bg-white py-3 rounded-md uppercase tracking-wider hover:bg-gray-50 transition-colors flex items-center justify-center"
                    onClick={() => setIsOpen(false)}
                  >
                    Fortsæt shopping
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ProductCard;
