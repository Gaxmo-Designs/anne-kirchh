
import React from "react";
import { motion } from "framer-motion";
import ProductCard from "@/components/ProductCard";
import { Product } from "@/types/product";

interface ProductsGridProps {
  isLoading: boolean;
  filteredProducts: Product[];
}

const ProductsGrid: React.FC<ProductsGridProps> = ({ isLoading, filteredProducts }) => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        {isLoading ? (
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-400"></div>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8"
          >
            {filteredProducts.map((product) => (
              <motion.div 
                key={product.id} 
                className="fade-up-element"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <ProductCard
                  id={product.id}
                  name={product.name}
                  price={product.price}
                  primaryImage={product.primaryImage}
                  secondaryImage={product.secondaryImage}
                  description={product.description}
                  size={product.size}
                />
              </motion.div>
            ))}
          </motion.div>
        )}
        
        {!isLoading && filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <p className="text-lg text-muted-foreground">Ingen produkter fundet i denne kategori.</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProductsGrid;
