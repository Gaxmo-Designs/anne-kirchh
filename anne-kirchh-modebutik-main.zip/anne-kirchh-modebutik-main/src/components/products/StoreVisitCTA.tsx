
import React from "react";

const StoreVisitCTA: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="bg-gradient-to-b from-white to-purple-50 p-8 md:p-12 rounded-lg shadow-sm border border-purple-100 max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-2xl font-display mb-4 text-purple-800">Besøg vores butik i Værløse</h2>
              <p className="mb-6 text-muted-foreground font-serif">
                Kom forbi vores butik og oplev vores fulde kollektion. Vores personale står klar til at hjælpe dig med at finde det perfekte outfit.
              </p>
              <div className="space-y-3 font-sans">
                <p><strong className="text-pink-700">Adresse:</strong> Bymidten 43, 3500 Værløse</p>
                <p><strong className="text-pink-700">Telefon:</strong> 44 47 37 11</p>
                <p>
                  <strong className="text-pink-700">Åbningstider:</strong><br />
                  Mandag-fredag: 9.30-18.00<br />
                  Lørdag: 9.30-15.00
                </p>
              </div>
              <div className="mt-6">
                <a
                  href="https://maps.google.com/?q=Bymidten+43,+3500+Værløse"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center text-pink-600 hover:text-pink-800 transition-colors font-medium"
                >
                  <span>Find vej</span>
                  <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -top-4 -right-4 w-full h-full bg-pink-200 rounded-lg"></div>
              <img 
                src="/lovable-uploads/44d2beba-d8ed-4534-a37f-d3b38ba869b0.png" 
                alt="Anne Kirchh butik facade" 
                className="rounded-lg w-full h-auto object-cover relative z-10 border-4 border-white shadow-lg"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StoreVisitCTA;
