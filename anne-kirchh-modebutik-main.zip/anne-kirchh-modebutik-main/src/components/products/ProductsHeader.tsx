
import React from "react";

const ProductsHeader: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-pink-50 to-purple-50 relative">
      <div className="absolute top-0 right-0 w-32 h-32 bg-pink-200 rounded-full -mt-16 -mr-16 opacity-40"></div>
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-green-200 rounded-full -mb-12 -ml-12 opacity-40"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-display mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">Vores Produkter</h1>
          <p className="text-lg text-muted-foreground font-serif">
            Opdagede vores eksklusive udvalg af tøj og accessories til enhver lejlighed.
            Fra hverdags favoritter til festlige stykker.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ProductsHeader;
