
import React from "react";
import { Sparkles, ShoppingBag } from "lucide-react";

interface SeasonalBannerProps {
  onViewAllClick: () => void;
}

const SeasonalBanner: React.FC<SeasonalBannerProps> = ({ onViewAllClick }) => {
  return (
    <section className="py-16 bg-gradient-to-r from-green-50 to-green-100 my-8 relative overflow-hidden">
      <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-green-200 opacity-50"></div>
      <div className="absolute -bottom-16 -left-16 w-32 h-32 rounded-full bg-purple-200 opacity-50"></div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto">
          <div className="flex justify-center mb-4">
            <Sparkles className="text-pink-400 h-8 w-8" />
          </div>
          <h2 className="text-3xl font-display mb-4 text-green-800">Forårs Nyheder</h2>
          <p className="text-lg mb-6 font-serif">
            Opdagede vores nyeste kollektioner, designet til at give dit forårslook en forfriskende opdatering.
          </p>
          <button 
            onClick={onViewAllClick}
            className="bg-gradient-to-r from-purple-400 to-pink-400 text-white px-6 py-3 rounded-md hover:from-purple-500 hover:to-pink-500 transition-all duration-300 shadow-md flex items-center mx-auto"
          >
            <ShoppingBag className="mr-2 h-4 w-4" />
            <span>Se hele kollektionen</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default SeasonalBanner;
