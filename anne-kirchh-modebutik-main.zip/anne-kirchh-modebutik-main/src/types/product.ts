
export type Product = {
  id: number;
  name: string;
  price: string;
  category: string;
  primaryImage: string;
  secondaryImage?: string;
  description?: string;
  size?: string;
};

export type Category = "all" | "scarves" | "jackets" | "skirts" | "shoes" | "blazers" | "shirts" | "jeans" | "dresses" | "sweaters" | "bags" | "accessories";

export const categories = [
  { value: "all", label: "Alle" },
  { value: "scarves", label: "Tørklæder" },
  { value: "jackets", label: "Jakker" },
  { value: "skirts", label: "Nederdele" },
  { value: "shoes", label: "Sko" },
  { value: "blazers", label: "Blazere" },
  { value: "shirts", label: "Toppe & T-shirts" },
  { value: "jeans", label: "Bukser" },
  { value: "dresses", label: "Kjoler" },
  { value: "sweaters", label: "Strik" },
  { value: "bags", label: "Tasker" },
  { value: "accessories", label: "Tilbehør" }
];
