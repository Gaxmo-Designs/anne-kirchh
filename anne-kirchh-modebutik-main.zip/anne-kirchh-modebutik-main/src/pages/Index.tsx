
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, ShoppingBag } from "lucide-react";
import ImageWithPreload from "@/components/ui/ImageWithPreload";
import BrandMarquee from "@/components/BrandMarquee";

const Index = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const brands = [
    "Cream", 
    "B-Young", 
    "Freequent", 
    "KAFFE", 
    "PREPAIR", 
    "Ysabel Mora"
  ];

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center">
        <div className="absolute inset-0 z-0">
          <ImageWithPreload
            src="/lovable-uploads/c50744d9-dbe1-46ee-bee6-e1954e5eabf0.png"
            alt="Anne Kirchh butik facade"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/70"></div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-pink-400 blur-3xl opacity-20"></div>
        <div className="absolute bottom-1/4 right-1/4 w-32 h-32 rounded-full bg-purple-400 blur-3xl opacity-20"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-3xl text-white"
          >
            <motion.h2 
              className="text-5xl md:text-7xl font-display mb-8 text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-300"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              ANNE KIRCHH
            </motion.h2>
            <motion.p 
              className="text-xl md:text-2xl mb-4 font-serif"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              Velkommen til Anne Kirchh – Din eksklusive modebutik i Værløse
            </motion.p>
            <motion.p 
              className="text-lg md:text-xl mb-8 font-light"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              Vi klæder både unge piger og modne kvinder på til enhver lejlighed
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 30 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Link 
                to="/products" 
                className="bg-gradient-to-r from-pink-400 to-purple-400 text-white px-8 py-3 rounded-md inline-flex items-center group hover:from-pink-500 hover:to-purple-500 transition-all duration-300 shadow-md"
              >
                <span className="mr-2">Se vores kollektion</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* New Staff Section with the uploaded image */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <ImageWithPreload 
              src="/lovable-uploads/1a9cff55-ff28-4bde-bd9d-9b1ed5625275.png"
              alt="Anne Kirchh - Modebutik i Værløse"
              className="w-full h-auto rounded-lg shadow-md"
            />
          </div>
        </div>
      </section>
      
      {/* Collection Preview Section - Using old hero image here */}
      <section className="py-24 px-4 bg-gradient-to-b from-white to-purple-50 relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-pink-100 rounded-full -mt-32 -mr-32 opacity-50"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-green-100 rounded-full -mb-24 -ml-24 opacity-50"></div>
      
        <div className="container mx-auto relative z-10">
          <div className="text-center mb-16 fade-up-element">
            <div className="inline-block mb-4">
              <Sparkles className="h-8 w-8 text-pink-400" />
            </div>
            <h2 className="text-3xl md:text-5xl font-display mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-500">
              Tøj til enhver alder og enhver stil
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto font-serif">
              Hos Anne Kirchh klæder vi kvinder på – fra de unge modebevidste piger til den stilfulde, modne kvinde.
              Vores udvalg er nøje udvalgt til at kombinere trends, komfort og kvalitet.
            </p>
          </div>
        </div>
      </section>
      
      {/* Brands Section */}
      <BrandMarquee brands={brands} />
      
      {/* CTA Section - Removed heart icon */}
      <section className="py-24 relative">
        <div className="absolute inset-0 z-0">
          <ImageWithPreload
            src="/lovable-uploads/44d2beba-d8ed-4534-a37f-d3b38ba869b0.png"
            alt="Anne Kirchh butik facade"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/40"></div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-1/3 left-1/4 w-32 h-32 rounded-full bg-pink-500 blur-3xl opacity-20"></div>
        <div className="absolute bottom-1/3 right-1/4 w-24 h-24 rounded-full bg-purple-500 blur-3xl opacity-20"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-2xl mx-auto text-center text-white">
            <h2 className="text-3xl md:text-5xl font-display mb-6">Besøg vores butik i Værløse</h2>
            <p className="text-lg mb-8 font-serif">
              Kom ind og oplev vores eksklusive udvalg og få personlig styling rådgivning
            </p>
            <Link 
              to="/contact" 
              className="bg-gradient-to-r from-pink-400 to-purple-400 text-white px-8 py-3 rounded-md inline-flex items-center group hover:from-pink-500 hover:to-purple-500 transition-all duration-300 shadow-md"
            >
              <ShoppingBag className="mr-2 h-4 w-4" />
              <span>Find vej til butikken</span>
              <ArrowRight className="ml-2 w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
