
import React from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import ImageWithPreload from "@/components/ui/ImageWithPreload";

const Contact = () => {
  return (
    <div className="container mx-auto section-padding">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <h2 className="text-3xl md:text-4xl font-display mb-4">
          Besøg os i Værløse Bymidte
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Vi glæder os til at se dig i vores butik, hvor vi har et stort udvalg
          af tøj, accessories og smykker.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="rounded-lg overflow-hidden"
        >
          <div className="relative aspect-square md:aspect-[4/3] overflow-hidden">
            <ImageWithPreload
              src="/lovable-uploads/dea643ea-bf06-4956-a88c-8cb22fe0eae1.png"
              alt="Værløse bymidte"
              className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-1000"
            />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-col justify-center"
        >
          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <MapPin className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Adresse</h3>
                <p className="text-muted-foreground">
                  Anne Kirchh, Bymidten 43, 3500 Værløse
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Phone className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Telefon</h3>
                <a
                  href="tel:+4544473711"
                  className="text-muted-foreground hover-line"
                >
                  44 47 37 11
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Mail className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Email</h3>
                <a
                  href="mailto:butikkenak@gmail.com"
                  className="text-muted-foreground hover-line"
                >
                  butikkenak@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Åbningstider</h3>
                <p className="text-muted-foreground">
                  Mandag-fredag: 9.30-18.00
                  <br />
                  Lørdag: 9.30-15.00
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="font-medium text-lg mb-2">Sociale medier</h3>
            <div className="flex gap-4">
              <a
                href="https://www.facebook.com/butikannekirchh"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-primary/10 p-3 rounded-full hover:bg-primary/20 transition-colors"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-6 h-6 text-primary"
                >
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                </svg>
              </a>
              <a
                href="https://www.instagram.com/annekirchh/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-primary/10 p-3 rounded-full hover:bg-primary/20 transition-colors"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-6 h-6 text-primary"
                >
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                </svg>
              </a>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="mt-16">
        <div className="rounded-lg overflow-hidden">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2245.7783039731785!2d12.367334!3d55.781649899999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46524e7d57e326e7%3A0xda38a9aeda0fd2b6!2sAnne%20Kirchh%20Clothing%20Store!5e0!3m2!1sen!2sus!4v1741381234567!5m2!1sen!2sus"
            width="100%"
            height="450"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Anne Kirchh location"
            className="w-full"
          ></iframe>
        </div>
      </div>

      <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="rounded-lg overflow-hidden"
        >
          <div className="relative aspect-video overflow-hidden">
            <ImageWithPreload
              src="/lovable-uploads/44d2beba-d8ed-4534-a37f-d3b38ba869b0.png"
              alt="Anne Kirchh butiksfacade"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
              <div className="p-6 text-white">
                <h3 className="font-display text-xl mb-2">Åbningstider</h3>
                <p className="text-white/90">
                  Mandag-fredag: 9.30-18.00
                  <br />
                  Lørdag: 9.30-15.00
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Contact;
