
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import ImageWithPreload from "@/components/ui/ImageWithPreload";

const Collection = () => {
  return (
    <div className="pt-24">
      {/* Header */}
      <section className="py-16 bg-beige/30">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-serif mb-6">Vores Kollektion</h1>
            <p className="text-lg text-muted-foreground mb-12">
              Hos Anne Kirchh finder du et nøje udvalgt sortiment af tøj og accessories til kvinder i alle aldre. 
              Fra tidløse klassikere til sæsonens nyeste trends.
            </p>
            
            {/* Collection Links */}
            <div className="flex flex-col md:flex-row justify-center gap-6">
              <Link 
                to="/products" 
                className="bg-primary text-white px-6 py-3 rounded-md inline-flex items-center group hover:bg-primary/90 transition-all duration-300"
              >
                <span className="mr-2">Alle Produkter</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </Link>
              
              <Link 
                to="/spring-collection" 
                className="bg-green-500 text-white px-6 py-3 rounded-md inline-flex items-center group hover:bg-green-600 transition-all duration-300"
              >
                <span className="mr-2">Forårskollektion 2024</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Collection Options - New section with two options */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* All Products Option */}
            <div className="relative rounded-lg overflow-hidden group h-[500px] fade-up-element">
              <ImageWithPreload
                src="/lovable-uploads/b415f3cf-5371-4746-93ec-7ac95bb8ba6b.png"
                alt="Alle produkter"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
              <div className="absolute bottom-0 left-0 w-full p-8">
                <h3 className="text-2xl font-serif text-white mb-2">Alle Produkter</h3>
                <p className="text-white/90 mb-4">
                  Udforsk vores komplette udvalg af tøj og accessories til enhver lejlighed.
                </p>
                <Link 
                  to="/products" 
                  className="inline-flex items-center text-white group"
                >
                  <span>Se alle produkter</span>
                  <ArrowRight className="ml-2 w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>

            {/* Spring Collection 2024 Option */}
            <div className="relative rounded-lg overflow-hidden group h-[500px] fade-up-element">
              <ImageWithPreload
                src="/lovable-uploads/dea643ea-bf06-4956-a88c-8cb22fe0eae1.png"
                alt="Forårskollektion 2024"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
              <div className="absolute bottom-0 left-0 w-full p-8">
                <h3 className="text-2xl font-serif text-white mb-2">Forårskollektion 2024</h3>
                <p className="text-white/90 mb-4">
                  Oplev vores nyeste kollektion med friske farver og lette, luftige stoffer, 
                  der er perfekte til foråret.
                </p>
                <Link 
                  to="/spring-collection" 
                  className="inline-flex items-center text-white group"
                >
                  <span>Se forårskollektionen</span>
                  <ArrowRight className="ml-2 w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl font-serif mb-6 fade-up-element">Besøg os i Værløse</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto fade-up-element">
            Kom ind og oplev vores eksklusive kollektioner i butikken. Vores venlige personale står klar til at hjælpe dig med at finde den perfekte stil.
          </p>
          <Link 
            to="/contact" 
            className="bg-white text-primary px-8 py-3 rounded-md inline-flex items-center group hover:bg-white/90 transition-all duration-300 fade-up-element"
          >
            <span className="mr-2">Find vores butik</span>
            <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Collection;
