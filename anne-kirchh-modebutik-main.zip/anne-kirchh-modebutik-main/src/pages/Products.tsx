
import React, { useState, useEffect } from "react";
import { Category } from "@/types/product";
import { getProducts } from "@/data/productData";
import ProductsHeader from "@/components/products/ProductsHeader";
import CategoryFilter from "@/components/products/CategoryFilter";
import ProductsGrid from "@/components/products/ProductsGrid";
import SeasonalBanner from "@/components/products/SeasonalBanner";
import StoreVisitCTA from "@/components/products/StoreVisitCTA";

const Products = () => {
  const [selectedCategory, setSelectedCategory] = useState<Category>("all");
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fetch products when component mounts
    const fetchProducts = async () => {
      setIsLoading(true);
      const fetchedProducts = await getProducts();
      setProducts(fetchedProducts);
      setFilteredProducts(fetchedProducts);
      setIsLoading(false);
    };

    fetchProducts();
  }, []);

  useEffect(() => {
    // Filter products when category changes
    if (selectedCategory === "all") {
      setFilteredProducts(products);
    } else {
      setFilteredProducts(products.filter(product => product.category === selectedCategory));
    }
  }, [selectedCategory, products]);

  const handleViewAllClick = () => {
    setSelectedCategory("all");
    // Scroll to top for better UX
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="pt-16 overflow-hidden">
      {/* Header with decorative elements */}
      <ProductsHeader />

      {/* Filter Section */}
      <CategoryFilter 
        selectedCategory={selectedCategory} 
        setSelectedCategory={setSelectedCategory}
      />

      {/* Products Grid */}
      <ProductsGrid 
        isLoading={isLoading} 
        filteredProducts={filteredProducts}
      />

      {/* Seasons Sale Banner */}
      <SeasonalBanner onViewAllClick={handleViewAllClick} />

      {/* Visit Store CTA */}
      <StoreVisitCTA />
    </div>
  );
};

export default Products;
