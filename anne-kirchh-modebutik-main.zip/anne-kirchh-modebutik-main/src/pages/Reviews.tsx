
import React from "react";
import { motion } from "framer-motion";
import ReviewCard from "@/components/ReviewCard";
import { Star, Sparkles } from "lucide-react";

const Reviews = () => {
  const reviews = [
    {
      name: "Dorota Jonas",
      comment: "Lækker butik!",
      rating: 5,
    },
    {
      name: "Morten Thomsen",
      comment: "Godt udvalg og venligt personale",
      rating: 5,
    },
    {
      name: "Bente Andersen",
      comment: "",
      rating: 5,
    },
  ];

  return (
    <div className="container mx-auto section-padding">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16 relative"
      >
        {/* Decorative elements */}
        <div className="absolute top-0 right-1/4 w-16 h-16 rounded-full bg-pink-100 -z-10"></div>
        <div className="absolute bottom-0 left-1/4 w-20 h-20 rounded-full bg-purple-100 -z-10"></div>
        
        <div className="flex justify-center mb-4">
          <Sparkles className="text-pink-400 h-8 w-8" />
        </div>
        <h2 className="text-3xl md:text-5xl font-display mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-pink-500">
          Vores kunders mening betyder alt
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto font-serif">
          Vi sætter stor pris på feedback fra vores kunder. Her er hvad nogle af
          dem siger om deres oplevelse hos Anne Kirchh.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {reviews.map((review, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 * index }}
            className="fade-up-element"
          >
            <ReviewCard
              name={review.name}
              comment={review.comment}
              rating={review.rating}
            />
          </motion.div>
        ))}
      </div>

      <div className="mt-16 text-center">
        <a
          href="https://www.google.com/search?sa=X&sca_esv=d2412773b0b8d781&tbm=lcl&sxsrf=AHTn8zqNGW_nl1C6j0yv09mI2NjvliLA7Q:1741378292262&q=Anne+Kirchh+v/+Mette+Morgan+Reviews&rflfq=1&num=20&stick=H4sIAAAAAAAAAONgkxIxNDU3AiJjC0tzIwtTI0MDCyODDYyMrxiVHfPyUhW8M4uSMzIUyvQVfFNLSlIVfPOL0hPzFIJSyzJTy4sXsRKjCgDEOGGtZwAAAA&rldimm=15725723897285210820&hl=en-DK&ved=2ahUKEwjUoZ7U4_iLAxXiKhAIHQOSMXIQ9fQKegQIWhAF&biw=2133&bih=1183&dpr=0.9#lkt=LocalPoiReviews"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-gradient-to-r from-purple-400 to-pink-400 text-white px-8 py-3 rounded-md inline-flex items-center group hover:from-purple-500 hover:to-pink-500 transition-all duration-300 shadow-md"
        >
          <Star className="mr-2 h-4 w-4" />
          <span>Se flere anmeldelser på Google</span>
        </a>
      </div>
    </div>
  );
};

export default Reviews;
