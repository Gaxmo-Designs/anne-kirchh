
import React, { useState, useEffect } from "react";
import ProductCard from "@/components/ProductCard";
import { motion } from "framer-motion";
import { Sparkles, ShoppingBag, Leaf } from "lucide-react";
import ImageWithPreload from "@/components/ui/ImageWithPreload";

// Define product types
type Product = {
  id: number;
  name: string;
  price: string;
  category: string;
  primaryImage: string;
  secondaryImage?: string;
  description?: string;
  size?: string;
};

const SpringCollection = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching products - in a real app, this would be an API call
    const fetchProducts = () => {
      setIsLoading(true);
      // Simulate network delay
      setTimeout(() => {
        const fetchedProducts: Product[] = [
          {
            id: 1,
            name: "Farverigt tørklæde - Blå/orange",
            price: "299,95 kr.",
            category: "scarves",
            primaryImage: "/lovable-uploads/b415f3cf-5371-4746-93ec-7ac95bb8ba6b.png",
            description: "Lækkert tørklæde i flotte farver. Perfekt til at give dit outfit et farverigt touch."
          },
          {
            id: 2,
            name: "Farverigt tørklæde - Pink/lilla",
            price: "299,95 kr.",
            category: "scarves",
            primaryImage: "/lovable-uploads/dea643ea-bf06-4956-a88c-8cb22fe0eae1.png",
            description: "Lækkert tørklæde i varme farver. Perfekt til at give dit outfit et farverigt touch."
          },
          {
            id: 3,
            name: "Denim jakke",
            price: "599,95 kr.",
            category: "jackets",
            primaryImage: "/lovable-uploads/7-6.png",
            secondaryImage: "/lovable-uploads/7-7.png",
            description: "Klassisk denim jakke i høj kvalitet. Et must-have i enhver garderobe."
          },
          {
            id: 4,
            name: "Ballon nederdel - Beige",
            price: "399,95 kr.",
            category: "skirts",
            primaryImage: "/lovable-uploads/10-9.png",
            secondaryImage: "/lovable-uploads/10-10.png",
            description: "Elegant ballon nederdel i beige. Perfekt til både hverdag og fest.",
            size: "S, M, L"
          },
          {
            id: 5,
            name: "Mesh ballerina sko med similisten",
            price: "349,95 kr.",
            category: "shoes",
            primaryImage: "/lovable-uploads/11-11.png",
            secondaryImage: "/lovable-uploads/12-12.png",
            description: "Elegante mesh ballerina sko med similisten. Komfortable og stilfulde."
          },
          {
            id: 11,
            name: "Offwhite kjole med smock fra Cream",
            price: "599,95 kr.",
            category: "dresses",
            primaryImage: "/lovable-uploads/24-24.png",
            secondaryImage: "/lovable-uploads/25-25.png",
            description: "Elegant offwhite kjole med smock fra Cream. 100% viskose.",
            size: "36-44"
          },
          {
            id: 12,
            name: "Blå kjole med smock fra Cream",
            price: "599,95 kr.",
            category: "dresses",
            primaryImage: "/lovable-uploads/26-26.png",
            description: "Smuk blå kjole med smock fra Cream. 100% viskose.",
            size: "36-44"
          },
          {
            id: 17,
            name: "Strikbluse - Blå",
            price: "299,95 kr.",
            category: "sweaters",
            primaryImage: "/lovable-uploads/32-32.png",
            description: "Blød strikbluse i smuk blå farve. Perfekt til kølige dage.",
            size: "S, M, L, XL"
          },
          {
            id: 18,
            name: "Strikbluse - Grøn",
            price: "299,95 kr.",
            category: "sweaters",
            primaryImage: "/lovable-uploads/33-33.png",
            description: "Blød strikbluse i flot grøn farve. Komfortabel og stilfuld.",
            size: "S, M, L, XL"
          },
          {
            id: 19,
            name: "Skjorte - Blå/rosa strib",
            price: "499,95 kr.",
            category: "shirts",
            primaryImage: "/lovable-uploads/36-36.png",
            description: "Elegant skjorte i blå med rosa broderi. Perfekt til både hverdag og fest.",
            size: "S, M, L"
          },
          {
            id: 20,
            name: "Taske fra Redesigned",
            price: "800,00 kr.",
            category: "bags",
            primaryImage: "/lovable-uploads/37-37.png",
            secondaryImage: "/lovable-uploads/39-39.png",
            description: "Håndlavet lædertaske fra Redesigned. Rummelig og i tidløst design."
          }
        ];

        setProducts(fetchedProducts);
        setIsLoading(false);
      }, 500);
    };

    fetchProducts();
  }, []);

  return (
    <div className="pt-16 overflow-hidden">
      {/* Header with decorative elements */}
      <section className="py-16 bg-gradient-to-r from-green-50 to-green-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-pink-200 rounded-full -mt-16 -mr-16 opacity-40"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-green-200 rounded-full -mb-12 -ml-12 opacity-40"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div className="mb-6 inline-flex items-center justify-center p-2 bg-white rounded-full shadow-sm">
              <Leaf className="h-8 w-8 text-green-500" />
            </div>
            <h1 className="text-4xl md:text-6xl font-display mb-6 bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-green-400">Forårskollektion 2024</h1>
            <p className="text-lg text-muted-foreground font-serif">
              Oplev vores nye kollektion med friske farver og lette, luftige stoffer, der er perfekte til foråret.
              Håndplukket til at give dit garderobe en forfriskende opdatering.
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-400"></div>
            </div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8"
            >
              {products.map((product) => (
                <motion.div 
                  key={product.id} 
                  className="fade-up-element"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <ProductCard
                    id={product.id}
                    name={product.name}
                    price={product.price}
                    primaryImage={product.primaryImage}
                    secondaryImage={product.secondaryImage}
                    description={product.description}
                    size={product.size}
                  />
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* Fashion Tips Section */}
      <section className="py-16 bg-gradient-to-r from-pink-50 to-purple-50 my-8 relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-48 h-48 rounded-full bg-green-200 opacity-50"></div>
        <div className="absolute -bottom-16 -left-16 w-32 h-32 rounded-full bg-purple-200 opacity-50"></div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
            <div>
              <div className="flex justify-start mb-4">
                <Sparkles className="text-pink-400 h-8 w-8" />
              </div>
              <h2 className="text-3xl font-display mb-4 text-green-800">Forårets Modetips</h2>
              <p className="text-lg mb-6 font-serif">
                Foråret bringer lysere dage og mulighed for at eksperimentere med din stil. Her er vores bedste tips til sæsonen:
              </p>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">
                    <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                  </span>
                  <span>Lag på lag giver dig fleksibilitet, når temperaturen svinger</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">
                    <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                  </span>
                  <span>Pastelfarver og blomstermønstre er altid et hit om foråret</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">
                    <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                  </span>
                  <span>Tilføj farve med accessories som tørklæder og smykker</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-green-100 text-green-600 rounded-full p-1 mr-2 mt-1">
                    <svg className="h-3 w-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                  </span>
                  <span>Lette, luftige stoffer som bomuld og hør holder dig kølig</span>
                </li>
              </ul>
            </div>
            <div className="relative">
              <div className="absolute -top-4 -right-4 w-full h-full bg-pink-200 rounded-lg opacity-30"></div>
              <ImageWithPreload 
                src="/lovable-uploads/07a2d613-4988-4ee5-af0c-8c136b727fbe.png"
                alt="Forår mode inspiration"
                className="rounded-lg w-full h-auto object-cover relative z-10 border-4 border-white shadow-lg aspect-[3/4]"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SpringCollection;
