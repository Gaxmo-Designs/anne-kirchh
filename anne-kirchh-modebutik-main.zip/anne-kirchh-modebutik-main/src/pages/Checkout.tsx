
import React, { useState } from "react";
import { useCart } from "@/context/CartContext";
import { Link, useNavigate } from "react-router-dom";
import { Check, ArrowLeft, CreditCard, Truck, Home } from "lucide-react";
import ImageWithPreload from "@/components/ui/ImageWithPreload";
import { useToast } from "@/components/ui/use-toast";

const Checkout = () => {
  const { cartItems, cartTotal, clearCart } = useCart();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    postalCode: "",
    city: "",
    paymentMethod: "card"
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentStep < 3) {
      setCurrentStep(prev => prev + 1);
    } else {
      // Process order
      toast({
        title: "Ordre modtaget!",
        description: "Tak for din bestilling. Du vil modtage en bekræftelse på e-mail.",
      });
      clearCart();
      navigate("/order-confirmation");
    }
  };

  const goBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    } else {
      navigate(-1);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="pt-32 pb-20 px-4">
        <div className="max-w-lg mx-auto text-center">
          <div className="bg-pink-50 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
            <CreditCard className="h-10 w-10 text-pink-500" />
          </div>
          <h1 className="text-3xl font-display mb-4">Din kurv er tom</h1>
          <p className="text-muted-foreground mb-8">
            Du har ingen varer i din indkøbskurv. Gå tilbage til butikken for at finde dejligt tøj til din garderobe.
          </p>
          <Link
            to="/products"
            className="bg-gradient-to-r from-pink-400 to-purple-400 text-white px-8 py-3 rounded-md inline-flex items-center group hover:from-pink-500 hover:to-purple-500 transition-all duration-300"
          >
            <span className="mr-2">Gå til butikken</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 pb-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Breadcrumb and back button */}
          <div className="flex items-center mb-8">
            <button 
              onClick={goBack}
              className="text-gray-500 hover:text-gray-800 flex items-center"
            >
              <ArrowLeft size={16} className="mr-1" />
              <span>Tilbage</span>
            </button>
            <div className="flex-1 flex justify-center">
              <div className="flex items-center">
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${currentStep >= 1 ? 'bg-green-500 text-white' : 'bg-gray-200'}`}>
                  {currentStep > 1 ? <Check size={16} /> : 1}
                </div>
                <div className={`w-16 h-1 ${currentStep >= 2 ? 'bg-green-500' : 'bg-gray-200'}`}></div>
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${currentStep >= 2 ? 'bg-green-500 text-white' : 'bg-gray-200'}`}>
                  {currentStep > 2 ? <Check size={16} /> : 2}
                </div>
                <div className={`w-16 h-1 ${currentStep >= 3 ? 'bg-green-500' : 'bg-gray-200'}`}></div>
                <div className={`flex items-center justify-center w-8 h-8 rounded-full ${currentStep >= 3 ? 'bg-green-500 text-white' : 'bg-gray-200'}`}>
                  3
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left side - Order Summary */}
            <div className="lg:col-span-1 order-2 lg:order-1">
              <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
                <h2 className="text-xl font-display mb-4">Din bestilling</h2>
                
                <div className="max-h-80 overflow-y-auto mb-4 pr-2">
                  {cartItems.map((item, index) => (
                    <div key={`${item.id}-${item.size}-${index}`} className="flex py-3 border-b border-gray-100 last:border-0">
                      <div className="h-16 w-12 bg-gray-50 rounded overflow-hidden mr-3 flex-shrink-0">
                        <ImageWithPreload
                          src={item.image}
                          alt={item.name}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-medium line-clamp-1">{item.name}</h3>
                        <p className="text-xs text-gray-500">Størrelse: {item.size}</p>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-sm">{item.quantity} x {item.price}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="pt-4 border-t border-gray-100">
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Subtotal:</span>
                    <span>{cartTotal}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-muted-foreground">Forsendelse:</span>
                    <span>Gratis</span>
                  </div>
                  <div className="flex justify-between font-medium text-lg pt-2 border-t border-gray-100 mt-2">
                    <span>Total:</span>
                    <span>{cartTotal}</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right side - Checkout Form */}
            <div className="lg:col-span-2 order-1 lg:order-2">
              <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
                {currentStep === 1 && (
                  <>
                    <h2 className="text-xl font-display mb-6 flex items-center">
                      <Home className="mr-2 h-5 w-5" />
                      <span>Leveringsoplysninger</span>
                    </h2>
                    
                    <form onSubmit={handleSubmit}>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <label htmlFor="firstName" className="block text-sm font-medium mb-1">Fornavn</label>
                          <input
                            type="text"
                            id="firstName"
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleChange}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                          />
                        </div>
                        <div>
                          <label htmlFor="lastName" className="block text-sm font-medium mb-1">Efternavn</label>
                          <input
                            type="text"
                            id="lastName"
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleChange}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
                          <input
                            type="email"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                          />
                        </div>
                        <div>
                          <label htmlFor="phone" className="block text-sm font-medium mb-1">Telefon</label>
                          <input
                            type="tel"
                            id="phone"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                          />
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <label htmlFor="address" className="block text-sm font-medium mb-1">Adresse</label>
                        <input
                          type="text"
                          id="address"
                          name="address"
                          value={formData.address}
                          onChange={handleChange}
                          required
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                          <label htmlFor="postalCode" className="block text-sm font-medium mb-1">Postnummer</label>
                          <input
                            type="text"
                            id="postalCode"
                            name="postalCode"
                            value={formData.postalCode}
                            onChange={handleChange}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                          />
                        </div>
                        <div>
                          <label htmlFor="city" className="block text-sm font-medium mb-1">By</label>
                          <input
                            type="text"
                            id="city"
                            name="city"
                            value={formData.city}
                            onChange={handleChange}
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                          />
                        </div>
                      </div>
                      
                      <div className="mt-8">
                        <button 
                          type="submit"
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white py-3 rounded-md hover:from-pink-600 hover:to-purple-600 transition-colors"
                        >
                          Fortsæt til forsendelse
                        </button>
                      </div>
                    </form>
                  </>
                )}
                
                {currentStep === 2 && (
                  <>
                    <h2 className="text-xl font-display mb-6 flex items-center">
                      <Truck className="mr-2 h-5 w-5" />
                      <span>Forsendelsesmetode</span>
                    </h2>
                    
                    <form onSubmit={handleSubmit}>
                      <div className="space-y-4 mb-6">
                        <div className="border border-gray-200 rounded-lg p-4 flex items-start">
                          <input
                            type="radio"
                            id="shipping-standard"
                            name="shippingMethod"
                            value="standard"
                            className="mt-1 mr-3"
                            defaultChecked
                          />
                          <div>
                            <label htmlFor="shipping-standard" className="font-medium">Standard levering</label>
                            <p className="text-sm text-muted-foreground">2-4 arbejdsdage</p>
                            <p className="text-sm font-medium mt-1">Gratis</p>
                          </div>
                        </div>
                        
                        <div className="border border-gray-200 rounded-lg p-4 flex items-start">
                          <input
                            type="radio"
                            id="shipping-express"
                            name="shippingMethod"
                            value="express"
                            className="mt-1 mr-3"
                          />
                          <div>
                            <label htmlFor="shipping-express" className="font-medium">Ekspres levering</label>
                            <p className="text-sm text-muted-foreground">1-2 arbejdsdage</p>
                            <p className="text-sm font-medium mt-1">49,00 kr.</p>
                          </div>
                        </div>
                        
                        <div className="border border-gray-200 rounded-lg p-4 flex items-start">
                          <input
                            type="radio"
                            id="shipping-store"
                            name="shippingMethod"
                            value="store"
                            className="mt-1 mr-3"
                          />
                          <div>
                            <label htmlFor="shipping-store" className="font-medium">Afhentning i butik</label>
                            <p className="text-sm text-muted-foreground">Bymidten 43, 3500 Værløse</p>
                            <p className="text-sm font-medium mt-1">Gratis</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-8">
                        <button 
                          type="submit"
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white py-3 rounded-md hover:from-pink-600 hover:to-purple-600 transition-colors"
                        >
                          Fortsæt til betaling
                        </button>
                      </div>
                    </form>
                  </>
                )}
                
                {currentStep === 3 && (
                  <>
                    <h2 className="text-xl font-display mb-6 flex items-center">
                      <CreditCard className="mr-2 h-5 w-5" />
                      <span>Betalingsmetode</span>
                    </h2>
                    
                    <form onSubmit={handleSubmit}>
                      <div className="space-y-4 mb-6">
                        <div className="border border-gray-200 rounded-lg p-4 flex items-start">
                          <input
                            type="radio"
                            id="payment-card"
                            name="paymentMethod"
                            value="card"
                            checked={formData.paymentMethod === "card"}
                            onChange={handleRadioChange}
                            className="mt-1 mr-3"
                          />
                          <div className="flex-1">
                            <label htmlFor="payment-card" className="font-medium">Kreditkort</label>
                            <p className="text-sm text-muted-foreground">Secure payment with credit card</p>
                            <div className="flex items-center space-x-2 mt-2">
                              <img src="https://cdn-icons-png.flaticon.com/512/349/349221.png" alt="Visa" className="h-8" />
                              <img src="https://cdn-icons-png.flaticon.com/512/349/349228.png" alt="Mastercard" className="h-8" />
                            </div>
                          </div>
                        </div>
                        
                        <div className="border border-gray-200 rounded-lg p-4 flex items-start">
                          <input
                            type="radio"
                            id="payment-mobilepay"
                            name="paymentMethod"
                            value="mobilepay"
                            checked={formData.paymentMethod === "mobilepay"}
                            onChange={handleRadioChange}
                            className="mt-1 mr-3"
                          />
                          <div>
                            <label htmlFor="payment-mobilepay" className="font-medium">MobilePay</label>
                            <p className="text-sm text-muted-foreground">Betal nemt med MobilePay</p>
                          </div>
                        </div>
                      </div>
                      
                      {formData.paymentMethod === "card" && (
                        <div className="bg-gray-50 rounded-lg p-5 border border-gray-200 mb-6">
                          <div className="mb-4">
                            <label className="block text-sm font-medium mb-1">Kortnummer</label>
                            <input
                              type="text"
                              placeholder="1234 5678 9012 3456"
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 mb-4">
                            <div>
                              <label className="block text-sm font-medium mb-1">Udløbsdato</label>
                              <input
                                type="text"
                                placeholder="MM/ÅÅ"
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium mb-1">Sikkerhedskode</label>
                              <input
                                type="text"
                                placeholder="CVC"
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                              />
                            </div>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium mb-1">Navn på kort</label>
                            <input
                              type="text"
                              placeholder="NAVN EFTERNAVNSEN"
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400"
                            />
                          </div>
                        </div>
                      )}
                      
                      <div className="mb-6">
                        <div className="flex items-start">
                          <input
                            type="checkbox"
                            id="terms"
                            className="mt-1 mr-2"
                            required
                          />
                          <label htmlFor="terms" className="text-sm">
                            Jeg accepterer <a href="#" className="text-pink-600 hover:underline">handelsbetingelserne</a> og har læst <a href="#" className="text-pink-600 hover:underline">privatlivspolitikken</a>
                          </label>
                        </div>
                      </div>
                      
                      <div className="mt-8">
                        <button 
                          type="submit"
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white py-3 rounded-md hover:from-pink-600 hover:to-purple-600 transition-colors"
                        >
                          Gennemfør køb
                        </button>
                      </div>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
