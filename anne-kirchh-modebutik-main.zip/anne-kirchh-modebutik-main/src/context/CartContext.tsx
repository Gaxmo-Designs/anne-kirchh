
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from "@/components/ui/use-toast";

export interface CartItem {
  id: number;
  name: string;
  price: string;
  image: string;
  size: string;
  quantity: number;
}

interface CartContextType {
  cartItems: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (itemId: number, size: string) => void;
  updateQuantity: (itemId: number, size: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: string;
  cartCount: number;
  isCartOpen: boolean;
  setIsCartOpen: (isOpen: boolean) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { toast } = useToast();
  
  // Load cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      try {
        setCartItems(JSON.parse(savedCart));
      } catch (error) {
        console.error('Failed to parse cart from localStorage', error);
      }
    }
  }, []);
  
  // Save cart to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems]);
  
  const addToCart = (newItem: CartItem) => {
    setCartItems(prevItems => {
      // Check if item with same id and size already exists
      const existingItemIndex = prevItems.findIndex(
        item => item.id === newItem.id && item.size === newItem.size
      );
      
      if (existingItemIndex > -1) {
        // Update quantity of existing item
        const updatedItems = [...prevItems];
        updatedItems[existingItemIndex].quantity += newItem.quantity;
        
        toast({
          title: "Opdateret antal",
          description: `${newItem.name} (${newItem.size}): ${updatedItems[existingItemIndex].quantity} stk.`,
        });
        
        return updatedItems;
      } else {
        // Add new item
        toast({
          title: "Tilføjet til kurven",
          description: `${newItem.name} (${newItem.size}): ${newItem.quantity} stk.`,
        });
        
        return [...prevItems, newItem];
      }
    });
  };
  
  const removeFromCart = (itemId: number, size: string) => {
    setCartItems(prevItems => 
      prevItems.filter(item => !(item.id === itemId && item.size === size))
    );
    
    toast({
      title: "Fjernet fra kurven",
      description: "Varen er fjernet fra din kurv.",
    });
  };
  
  const updateQuantity = (itemId: number, size: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId, size);
      return;
    }
    
    setCartItems(prevItems => 
      prevItems.map(item => 
        item.id === itemId && item.size === size
          ? { ...item, quantity }
          : item
      )
    );
  };
  
  const clearCart = () => {
    setCartItems([]);
    toast({
      title: "Kurven er tømt",
      description: "Alle varer er fjernet fra din kurv.",
    });
  };
  
  // Calculate total price
  const cartTotal = cartItems.reduce((total, item) => {
    const priceValue = parseFloat(item.price.replace(/[^0-9,]/g, '').replace(',', '.'));
    return total + (priceValue * item.quantity);
  }, 0).toFixed(2).replace('.', ',') + " kr.";
  
  // Calculate total items count
  const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);
  
  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      cartTotal,
      cartCount,
      isCartOpen,
      setIsCartOpen
    }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
